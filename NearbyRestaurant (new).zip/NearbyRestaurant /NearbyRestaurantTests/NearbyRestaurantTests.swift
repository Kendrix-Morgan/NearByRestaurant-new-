//
//  NearbyRestaurantTests.swift
//  NearbyRestaurantTests
//
//  Created by Kendrix on 2025/01/20.
//

import Testing
@testable import NearbyRestaurant

struct NearbyRestaurantTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
