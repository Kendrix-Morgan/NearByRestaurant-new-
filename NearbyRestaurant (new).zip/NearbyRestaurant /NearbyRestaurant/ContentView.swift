//
//  ContentView.swift
//  NearbyRestaurant
//
//  Created by Kendrix on 2025/01/20.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            SearchView()
        }
      
    }
}

#Preview {
    ContentView()
}
