//
//  DetailsView.swift
//  NearbyRestaurant
//
//  Created by Kendrix on 2025/01/20.
//
import SwiftUI

struct DetailsView: View {
    let restaurant: Restaurant

    var body: some View {
        VStack{
            Text("詳しい情報")
                .font(.system(size: 34))
                .fontWeight(.bold)
            
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                AsyncImage(url: URL(string: restaurant.imageURL)) { image in
                    image.resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(height: 200)
                        .cornerRadius(12)
                } placeholder: {
                    ProgressView()
                }
                
                Text(restaurant.name).font(.largeTitle).bold()
                Text("Address: \n\(restaurant.address)").font(.body)
                Text("Business Hours: \n\(restaurant.businessHours)").font(.body)
                
               
                Spacer()

                    Button(action:{
                        openInMaps()
                    })
                    {
                        HStack{
                            Image("map")
                                .resizable()
                                .aspectRatio(contentMode: .fill)
                                .frame(width: 80)
                            Text("Open in Maps")
                                .frame(width: 150)
                                .padding()
                                .background(Color.blue)
                                .foregroundColor(.white)
                                .cornerRadius(10)
                        }.frame(maxWidth: .infinity,alignment: .center)
                    }
            }
            .padding()
        }
    }
      
    }
  
    
    private func openInMaps() {
        let url = "maps://?q=\(restaurant.name)&ll=\(restaurant.latitude),\(restaurant.longitude)"
        if let encoded = url.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed),
           let mapURL = URL(string: encoded) {
            UIApplication.shared.open(mapURL)
        }
    }
}
