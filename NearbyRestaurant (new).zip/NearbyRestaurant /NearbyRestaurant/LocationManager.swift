//
//  LocationManager.swift
//  NearbyRestaurant
//
//  Created by Kendrix on 2025/01/28.
//

import CoreLocation

class LocationManager: NSObject, ObservableObject, CLLocationManagerDelegate {
    private var locationManager = CLLocationManager()
    private let geocoder = CLGeocoder()

    @Published var latitude: Double = 0.0
    @Published var longitude: Double = 0.0
    @Published var cityName: String = "" // New: Store the city name
    @Published var locationError: String?

    override init() {
        super.init()
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
    }

    func startUpdatingLocation() {
        locationManager.startUpdatingLocation()
    }

    func stopUpdatingLocation() {
        locationManager.stopUpdatingLocation()
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.first else { return }
        latitude = location.coordinate.latitude
        longitude = location.coordinate.longitude

        // Perform reverse geocoding to fetch city name
        let locale = Locale(identifier: "ja_JP") // Japanese locale
        geocoder.reverseGeocodeLocation(location, preferredLocale: locale) { [weak self] placemarks, error in
                if let error = error {
                self?.locationError = error.localizedDescription
                return
            }

            if let placemark = placemarks?.first {
                self?.cityName = placemark.locality ?? "" // Update city name
            }
        }
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        locationError = error.localizedDescription
    }
}
