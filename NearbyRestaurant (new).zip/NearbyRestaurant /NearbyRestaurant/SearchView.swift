//
//  SearchView.swift
//  NearbyRestaurant
//
//  Created by Kendrix on 2025/01/20.
//

import SwiftUI
import CoreLocation

struct SearchView: View {
    @State private var latitude: Double = 0.0
    @State private var longitude: Double = 0.0
    @State private var radius: Int = 1
    @State private var keyword: String = ""
    @State private var showResults = false
    @StateObject private var locationManager = LocationManager()
    
    @State private var recommendedRestaurants: [Restaurant] = []
    @State private var isLoadingRecommended = true
    
    var body: some View {
        NavigationView {
            VStack {
                Text("Restaurants Search")
                    .font(.system(size: 34))
                    .fontWeight(.bold)
                    .padding(.trailing,80)
                
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 50) {
                    ForEach(PhotoData.photos) { photo in
                        VStack {
                            Button(action: {
                                keyword = photo.label  // Set keyword based on button label
                                showResults = true  // Trigger navigation
                            }) {
                                Image(photo.imageName)
                                .resizable()
                                .scaledToFill()
                                .frame(width: 50, height: 65)
                            }
                                Text(photo.label)
                                .font(.headline)
                                .foregroundColor(.primary)
                                .padding(.top, 20)
                            }
                        }
                     }//HStack
                    .padding(.leading,30)
                }//ScrollView

                
                // Recommended restaurants section
                Text("Recommended Restaurants in \(locationManager.cityName.isEmpty ? " Your Area" : locationManager.cityName)")
                    .font(.title2)
                    .bold()
                    .padding(.top, 30)
                    .padding(.trailing, 80)

                if isLoadingRecommended {
                        ProgressView("Loading Recommended Restaurants...")
                    } else {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 30) {
                            ForEach(recommendedRestaurants) { restaurant in
                                NavigationLink(destination: DetailsView(restaurant: restaurant)) {
                                    VStack {
                                        AsyncImage(url: URL(string: restaurant.imageURL)) { image in
                                            image.resizable()
                                            .scaledToFill()
                                            .frame(width: 120, height: 90)
                                            .cornerRadius(10)
                                        } placeholder: {
                                    ProgressView()
                                }
                        Text(restaurant.name)
                        .font(.subheadline)
                        .fontWeight(.bold)
                        .foregroundColor(.primary)
                        .multilineTextAlignment(.center)
                        .frame(width: 120)
                    }
                }
            }
        }
    }
}
                
        Button("Get Current Location First") {
            getLocation()
        }
        
        TextField("ジャンルや料理名を入力 (例: 寿司、ピザ)", text: $keyword)
            .textFieldStyle(RoundedBorderTextFieldStyle())
            .padding()
                
        Picker("Search Radius (km)", selection: $radius) {
            ForEach(1...5, id: \.self) { distance in
                Text("\(distance) km").tag(distance)
                }
            }
            .pickerStyle(SegmentedPickerStyle())
            .padding()

        NavigationLink(destination: ResultsView(latitude: latitude, longitude: longitude, radius: radius, keyword: keyword)) {
            Text("Search")
              .frame(maxWidth: .infinity)
              .padding()
              .foregroundColor(.white)
              .background(Color.blue)
              .cornerRadius(10)
        }
                .padding()
                .disabled(latitude == 0 && longitude == 0)
            }
            .frame(width: 400,height: 900)
            .onAppear {
                locationManager.startUpdatingLocation()
            }
            .onChange(of: locationManager.latitude) {
                if locationManager.latitude != 0.0 && locationManager.longitude != 0.0 {
                    fetchRecommendedRestaurants()
                }
            }
        }
    }

    private func fetchRecommendedRestaurants() {
        ApiClient.shared.fetchRecommendedRestaurants(latitude: locationManager.latitude, longitude: locationManager.longitude) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let data):
                    recommendedRestaurants = data
                    isLoadingRecommended = false
                case .failure(let error):
                    print("Error fetching recommended restaurants: \(error.localizedDescription)")
                    isLoadingRecommended = false
                }
            }
        }
    }
    
    private func getLocation() {
        locationManager.startUpdatingLocation()
        latitude = locationManager.latitude
        longitude = locationManager.longitude
    }
}

#Preview {
    SearchView()
}
